export enum UserRole {
  Admin = 'Admin',
  User = 'User'
}
