export interface MessageContact {
  userId: number;
  userName: string;
}
