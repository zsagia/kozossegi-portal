export interface Post {
  id: number;
  fromUser: number;
  userName?: string;
  text: string;
  timestamp: string;
}
