export interface UserNotification {
  id: number;
  forUser: number;
  message: string;
}
